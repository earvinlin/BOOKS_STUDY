//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileCopy.rc
//
#define IDC_PATHNAME                    100
#define IDC_SRCFILE                     101
#define IDC_SRCFILESIZE                 102
#define IDI_FILECOPY                    103
#define IDD_FILECOPY                    104

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
